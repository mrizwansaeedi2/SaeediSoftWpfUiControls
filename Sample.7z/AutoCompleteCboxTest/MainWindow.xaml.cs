﻿using SaeediSoftWpfUiControls;

using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace AutoCompleteCboxTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ObservableCollection<SearchModel> dataList = new ObservableCollection<SearchModel>
            {
                new SearchModel(){DisplayField = "Ali",StringFeild1 = "Ali"},
                new SearchModel(){DisplayField = "Frahan",StringFeild1 = "Frahan"},
                new SearchModel(){DisplayField = "Raza",StringFeild1 = "Raza"},
            };

            uc_cbox.ItemsSource = dataList;
        }

        private void _comboBoxControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            var seletion = uc_cbox.Ctrl.SelectedItem as SearchModel;
            if (seletion is not null)
            {
                MessageBox.Show($"{seletion.DisplayField} Selected");
            }
        }

        private async void autoCompleteComboBox_Loaded(object sender, RoutedEventArgs e)
        { 
            await Task.Factory.StartNew(() => { Thread.Sleep(100); });
            if (uc_cbox.Ctrl is not null)
            {
                // Attach Events -------------------------
                uc_cbox.Ctrl.SelectionChanged += _comboBoxControl_SelectionChanged;
            }
        }
    }
}
